#!/bin/bash

PROG=$0

usage() { echo "Usage: $PROG  [-s <source_image>] [-c <cpus>] [-m <mem>] [-n <macaddr>] vm_name ssh-forward-port login" 1>&2; exit 1; }

echo "Initializing parameters"

# Default values
CPU=2
MEM=4G
MACADDR_USER="$(echo 52:54:50$(od -txC -An -N3 /dev/random|tr \  :))"
MACADDR_TAP="$(echo 52:54:50$(od -txC -An -N3 /dev/random|tr \  :))"
SOURCE="/data/example.qcow2"

# Override with command line parameters
while getopts "c:m:n:s:" opt; do
    case "${opt}" in
        c)
            CPUS=${OPTARG}
            ;;
        m)
            MEM=${OPTARG}
            ;;
        n)
            MACADDR_USER=${OPTARG}
            ;;
        s)
            SOURCE=${OPTARG}
            ;;
        *)
            usage
            ;;
    esac
done

shift $((OPTIND-1))
# The VM name
NAME=$1
if [[ -z "$NAME" ]]; then
    usage
fi

# The SSH forwarding port
SSHFORWARD=$2
if [[ -z "$SSHFORWARD" ]]; then
    usage
fi

# The login
LOGIN=$3
if [[ -z "$LOGIN" ]]; then
    usage
fi

# Work directory for our VM manager
# Make sure it exists
ROOTDIR="/data/vmmgr/$(hostname)"
mkdir -p "$ROOTDIR" || { echo 'Failed to create root directory' 1>&2 ; exit 1; }

# The image file for our VM
IMGFILE="$ROOTDIR/$NAME.img"
# The pidfile for our VM
PIDFILE="$ROOTDIR/$NAME.pid"
# The pidfile for our VM
LOGFILE="$ROOTDIR/$NAME.log"
# User cloud config file
USERFILE="$ROOTDIR/$NAME-user-data"
# Metadata config file
METAFILE="$ROOTDIR/$NAME-meta-data"
# File for the ISO
CONFIGSEED="$ROOTDIR/$NAME.iso"

# A little bit of a hack but let's use the forwarding port as the instance ID
INSTANCEID=$SSHFORWARD

# Basic check to make sure this VM is not yet running
# This is far frome robust and is not an example for production code !
if [[ -f $PIDFILE ]]; then
    kill -0 $(cat $PIDFILE) && { echo 'VM is running' 1>&2 ; exit 1; }
    echo 'VM is dead but pid file exists' 1>&2
    echo 'Please run ./delete_vm.sh' 1>&2
    exit 1
fi

echo "... Finished parameters initialization"
echo "Creating config files $USERFILE and $METAFILE"

# Meta
echo "instance-id: $INSTANCEID" > $METAFILE
echo "local-hostname: $NAME" > $METAFILE

# Cloud-config
printf "#cloud-config\n\nusers:\n -name: $LOGIN\n   sudo: ALL=(ALL) NOPASSWD:ALL\n   ssh_authorized_keys:\n       - $(cat ~/.ssh/id_rsa.pub)" > $USERFILE

echo "... Finished config files $USERFILE and $METAFILE"
echo "Creating ISO $CONFIGSEED"

genisoimage -output $CONFIGSEED -volid cidata -joliet -rock $USERFILE $METAFILE

echo "... Finished ISO $CONFIGSEED"
echo "Creating image file in $IMGFILE"

# Create a new image for this VM using the source image as backing file
# VM images are ephemeral so delete any old image
rm -f "$IMGFILE" 2>/dev/null
# -b is for the backing storage: only the differences to this original storage
# will be written in $IMGFILE: this allows for lots of VM based on the same
# source without duplicating the full VM each time
qemu-img create -f qcow2 -F qcow2 -b $SOURCE $IMGFILE || { echo 'Failed to create image' 1>&2 ; exit 1; }

echo "... Finished image creation in $IMGFILE"
echo "Setting up tap tap$NAME"

# Create a tap device and connect it to our network
#
# NOTE: the bridge and ethernet interface must have been set for this to work
# properly
ip tuntap add tap$NAME mode tap \
    && ip link set tap$NAME master br0 \
    && ip link set tap$NAME up \
    ||  { echo 'Failed to setup network' 1>&2 ; exit 1; }

echo "... Finished setting up tap tap$NAME"
echo "Launching VM"

# Launch the VM with qemu
# Use -pidfile option to store a pidfile
# Output console as a log in $LOGFILE instead of stdio
# Daemonize qemu so that in runs in the background
qemu-system-x86_64 \
    -nodefaults \
    -nographic  \
    -machine type=q35,accel=kvm  \
    -smp $CPU \
    -m $MEM  \
    -device virtio-net,netdev=nd1,mac=$MACADDR_USER \
    -netdev user,id=nd1,hostfwd=tcp::$SSHFORWARD-:22 \
    -device virtio-net,netdev=nd2,mac=$MACADDR_TAP \
    -netdev tap,id=nd2,script=no,downscript=no,br=br0,ifname=tap$NAME \
    -device virtio-blk,drive=bd1 \
    -blockdev driver=qcow2,node-name=bd1,discard=unmap,file.driver=file,file.filename=$IMGFILE \
    -device isa-serial,chardev=cd1 \
    -chardev file,id=cd1,path=$LOGFILE  \
    -pidfile $PIDFILE \
    -daemonize \
    -device virtio-scsi-pci,id=scsi0 \
    -device scsi-cd,bus=scsi0.0,drive=cd0 \
    -blockdev driver=file,node-name=cd0,filename=$CONFIGSEED \
    || { echo 'Failed to start Qemu' 1>&2 ; exit 1; }

    # Original option instead of -chardev file
    # -mon cd1 \
    # -chardev stdio,id=cd1,mux=on,signal=off

echo "VM has been launched"
echo " SSH Forward port: $SSHFORWARD"
echo " User mac address: $MACADDR_USER"
echo " Tap mac address:  $MACADDR_TAP"
echo " Dir:              $(dirname $IMGFILE)/"
