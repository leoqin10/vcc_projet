#!/bin/bash

PROG=$0

usage() { echo "Usage: $PROG vm_name" 1>&2; exit 1; }

# The VM name
NAME=$1
if [[ -z "$NAME" ]]; then
    usage
fi
# Work directory for our VM manager
ROOTDIR="/data/vmmgr/$(hostname)"
# The image file for our VM
IMGFILE="$ROOTDIR/$NAME.img"
# The pidfile for our VM
PIDFILE="$ROOTDIR/$NAME.pid"
# The logfile for our VM
LOGFILE="$ROOTDIR/$NAME.log"

if [[ -f $PIDFILE ]]; then
    kill -9 $(cat $PIDFILE) 2>/dev/null
fi

# Delete network TAP
ip tuntap del name tap$NAME mode tap

rm -f $IMGFILE 2>/dev/null
rm -f $PIDFILE 2>/dev/null
